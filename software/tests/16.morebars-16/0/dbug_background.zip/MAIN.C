
#include    "lib.h"

#include    "defines.h"


void ComputeDivMod();
void DrawBigLoop();


void main()
{
    ComputeDivMod();
    hires();

    DrawBigLoop();
}



